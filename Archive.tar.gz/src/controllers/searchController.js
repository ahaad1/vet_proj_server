const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Поиск по ключевым словам
exports.search = async (req, res) => {
  const { query } = req.query;

  try {
    const posts = await prisma.post.findMany({
      where: {
        OR: [
          { title: { contains: query, mode: 'insensitive' } },
          { description: { contains: query, mode: 'insensitive' } }
        ],
      },
      include: {
        user: true,
        category: true,
        country: true,
        region: true,
        city: true,
        district: true,
        animal: true,
      }
    });

    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при выполнении поиска' });
  }
};

// Фильтрация данных
exports.filter = async (req, res) => {
  const { categoryId, userId, country_id, region_id, city_id, district_id, animalId } = req.query;

  try {
    const posts = await prisma.post.findMany({
      where: {
        AND: [
          categoryId ? { categoryId: Number(categoryId) } : {},
          userId ? { userId: Number(userId) } : {},
          country_id ? { country_id: Number(country_id) } : {},
          region_id ? { region_id: Number(region_id) } : {},
          city_id ? { city_id: Number(city_id) } : {},
          district_id ? { district_id: Number(district_id) } : {},
          animalId ? { animalId: Number(animalId) } : {},
        ],
      },
      include: {
        user: true,
        category: true,
        country: true,
        region: true,
        city: true,
        district: true,
        animal: true,
      }
    });

    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при выполнении фильтрации' });
  }
};
