const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.createPost = async (req, res) => {
  const { title, description, categoryId, contactPhoneNum, expirationDate, imgUrls, country_id, region_id, city_id, district_id, animalId } = req.body;

  try {
    const post = await prisma.post.create({
      data: {
        title,
        description,
        categoryId,
        userId: req.user.userId,  // Используем ID пользователя из токена
        contactPhoneNum,
        expirationDate,
        imgUrls,
        country_id,
        region_id,
        city_id,
        district_id,
        animalId,
      },
    });
    res.status(201).json(post);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при создании поста' });
  }
};

exports.getPosts = async (req, res) => {
  try {
    const posts = await prisma.post.findMany({
      include: {
        user: true,
        category: true,
      }
    });
    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при получении постов' });
  }
};

exports.updatePost = async (req, res) => {
  const { id } = req.params;
  const { title, description, categoryId, contactPhoneNum, expirationDate, imgUrls, country_id, region_id, city_id, district_id, animalId } = req.body;

  try {
    const post = await prisma.post.findUnique({ where: { id: Number(id) } });

    if (post.userId !== req.user.userId && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Недостаточно прав для изменения этого поста' });
    }

    const updatedPost = await prisma.post.update({
      where: { id: Number(id) },
      data: {
        title,
        description,
        categoryId,
        contactPhoneNum,
        expirationDate,
        imgUrls,
        country_id,
        region_id,
        city_id,
        district_id,
        animalId,
      },
    });
    res.status(200).json(updatedPost);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при обновлении поста' });
  }
};

exports.deletePost = async (req, res) => {
  const { id } = req.params;

  try {
    const post = await prisma.post.findUnique({ where: { id: Number(id) } });

    if (post.userId !== req.user.userId && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Недостаточно прав для удаления этого поста' });
    }

    await prisma.post.delete({ where: { id: Number(id) } });
    res.status(204).json({ message: 'Пост удален' });
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при удалении поста' });
  }
};
